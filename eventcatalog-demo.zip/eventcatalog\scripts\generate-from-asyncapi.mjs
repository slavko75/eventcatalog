/**
 * Darmowy generator EventCatalog z plików AsyncAPI 2.x / 3.x
 * Używa wyłącznie @eventcatalog/sdk (bezpłatny) + js-yaml
 *
 * Uruchomienie: node scripts/generate-from-asyncapi.mjs
 *
 * Funkcje:
 *  - Generuje serwisy z sends/receives na podstawie publish/subscribe (2.x) lub operations (3.x)
 *  - Generuje eventy ze schematem payload (tabela properties + schema.json)
 *  - Manifest: usuwa serwisy/eventy gdy plik AsyncAPI zostanie usunięty
 */

import sdk from '@eventcatalog/sdk';
import yaml from 'js-yaml';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CATALOG_DIR = path.join(__dirname, '..');
const SPECS_DIR = path.join(CATALOG_DIR, 'asyncapi-specs');
const MANIFEST_PATH = path.join(CATALOG_DIR, '.asyncapi-manifest.json');

const { writeService, writeEvent, rmServiceById, rmEventById } = sdk(CATALOG_DIR);

// ─── Manifest ────────────────────────────────────────────────────────────────

function loadManifest() {
  if (!fs.existsSync(MANIFEST_PATH)) return {};
  try {
    return JSON.parse(fs.readFileSync(MANIFEST_PATH, 'utf8'));
  } catch {
    return {};
  }
}

function saveManifest(manifest) {
  fs.writeFileSync(MANIFEST_PATH, JSON.stringify(manifest, null, 2));
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function majorVersion(spec) {
  return parseInt((spec.asyncapi || '2').split('.')[0], 10);
}

function channelToEventId(channelName) {
  return channelName
    .split(/[.\-_]/)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join('');
}

function resolveRef(spec, ref) {
  if (!ref || !ref.startsWith('#/')) return undefined;
  return ref.slice(2).split('/').reduce((obj, key) => obj?.[key], spec);
}

// ─── Schema → Markdown ───────────────────────────────────────────────────────

function schemaToMarkdownTable(schema, spec, depth = 0) {
  if (!schema || schema.type !== 'object') return '';

  const indent = depth > 0 ? `${'  '.repeat(depth)}` : '';
  const rows = [];

  for (const [field, def] of Object.entries(schema.properties || {})) {
    const resolved = def['$ref'] ? resolveRef(spec, def['$ref']) || def : def;
    const required = (schema.required || []).includes(field) ? '✓' : '';
    const type = formatType(resolved);
    const description = resolved.description || resolved.doc || '';
    rows.push(`| \`${field}\` | ${type} | ${required} | ${description} |`);

    // Jeden poziom zagłębienia dla obiektów zagnieżdżonych
    if (resolved.type === 'object' && resolved.properties && depth === 0) {
      const nested = schemaToMarkdownTable(resolved, spec, depth + 1);
      if (nested) rows.push(nested);
    }
  }

  if (rows.length === 0) return '';

  if (depth === 0) {
    return [
      '| Pole | Typ | Wymagane | Opis |',
      '|------|-----|:--------:|------|',
      ...rows,
    ].join('\n');
  }

  return rows.map((r) => `${indent}${r}`).join('\n');
}

function formatType(def) {
  if (!def) return '—';
  if (def['$ref']) return `\`${def['$ref'].split('/').pop()}\``;
  if (def.type === 'array') {
    const items = def.items;
    if (items?.['$ref']) return `array<\`${items['$ref'].split('/').pop()}\`>`;
    if (items?.type) return `array<${items.type}>`;
    return 'array';
  }
  const base = def.type || '—';
  const format = def.format ? `(${def.format})` : '';
  const enumVals = def.enum ? ` [${def.enum.join(' | ')}]` : '';
  return `${base}${format}${enumVals}`;
}

// ─── Normalizacja operacji ────────────────────────────────────────────────────

// Rozwiązuje $ref z możliwym łańcuchem (channel message → component message)
function deepResolveRef(spec, obj) {
  if (!obj) return {};
  if (!obj['$ref']) return obj;
  const resolved = resolveRef(spec, obj['$ref']);
  // Jeszcze jeden poziom — channel/messages/X może wskazywać na components/messages/X
  if (resolved?.['$ref']) return resolveRef(spec, resolved['$ref']) || resolved;
  return resolved || {};
}

function normalizeOperations(spec) {
  const ops = [];

  if (majorVersion(spec) >= 3) {
    for (const [, opDef] of Object.entries(spec.operations || {})) {
      // Klucz kanału z "#/channels/myChannelKey" → "myChannelKey"
      const channelRef = opDef.channel?.['$ref'] || '';
      const channelKey = channelRef.replace(/^#\/channels\//, '').split('/')[0];
      const channelDef = spec.channels?.[channelKey] || {};

      // W 3.x address to prawdziwa nazwa topicu (np. "order.placed")
      // klucz kanału to tylko identyfikator (np. "orderPlacedChannel")
      const channelName = channelDef.address || channelKey;

      // Wiadomość: najpierw z listy operacji, potem z kanału
      let message = {};
      const opMessages = opDef.messages || [];

      if (opMessages.length > 0) {
        // Operacja wskazuje konkretną wiadomość (może być 2-poziomowy $ref)
        message = deepResolveRef(spec, opMessages[0]);
      } else {
        // Fallback: pierwsza wiadomość z definicji kanału
        const channelMessages = channelDef.messages || {};
        const firstKey = Object.keys(channelMessages)[0];
        if (firstKey) {
          message = deepResolveRef(spec, channelMessages[firstKey]);
        }
      }

      ops.push({
        channelName,
        action: opDef.action === 'send' ? 'send' : 'receive',
        message,
        channelDef,
      });
    }
  } else {
    for (const [channelName, channelDef] of Object.entries(spec.channels || {})) {
      const resolveMsg = (msg) => {
        if (!msg) return {};
        if (msg['$ref']) return resolveRef(spec, msg['$ref']) || {};
        return msg;
      };
      if (channelDef.publish) {
        ops.push({ channelName, action: 'send', message: resolveMsg(channelDef.publish.message), channelDef });
      }
      if (channelDef.subscribe) {
        ops.push({ channelName, action: 'receive', message: resolveMsg(channelDef.subscribe.message), channelDef });
      }
    }
  }

  return ops;
}

function buildSendsReceives(ops) {
  const sends = [];
  const receives = [];
  for (const { channelName, action } of ops) {
    const eventId = channelToEventId(channelName);
    if (action === 'send') sends.push({ id: eventId, version: '1.0.0' });
    else receives.push({ id: eventId, version: '1.0.0' });
  }
  return { sends, receives };
}

// ─── Generator zdarzeń ───────────────────────────────────────────────────────

async function generateEvents(ops, spec) {
  const generatedEventIds = [];

  for (const { channelName, action, message, channelDef } of ops) {
    if (action !== 'send') continue;

    const eventId = channelToEventId(channelName);
    const eventName = message.title || message.name || eventId;
    const summary = message.summary || channelDef.description || `Zdarzenie na kanale ${channelName}`;
    const schema = message.payload ? resolveRef(spec, message.payload['$ref']) || message.payload : undefined;

    // Tabela właściwości z payload schema
    const schemaTable = schema ? schemaToMarkdownTable(schema, spec) : '';
    const schemaSection = schemaTable
      ? `\n## Struktura payload\n\n${schemaTable}\n`
      : '';

    // schemaPath informuje EventCatalog o pliku schematu (zakładka Schema w UI)
    const hasSchema = !!schema;

    const eventDef = {
      id: eventId,
      name: eventName,
      version: '1.0.0',
      summary,
      ...(hasSchema ? { schemaPath: 'schema.json' } : {}),
      markdown: `## ${eventName}\n\n${summary}\n\nKanał: \`${channelName}\`\n${schemaSection}`,
    };

    await writeEvent(eventDef, { override: true }).catch((err) => {
      console.warn(`  ! event ${eventId}: ${err.message}`);
    });

    if (schema) {
      const schemaFilePath = path.join(CATALOG_DIR, 'events', eventId, 'schema.json');
      fs.mkdirSync(path.dirname(schemaFilePath), { recursive: true });
      fs.writeFileSync(schemaFilePath, JSON.stringify(schema, null, 2));
      console.log(`  ✓ event  → events/${eventId}/ (schema + table)`);
    } else {
      console.log(`  ✓ event  → events/${eventId}/`);
    }

    generatedEventIds.push(eventId);
  }

  return generatedEventIds;
}

// ─── Cleanup: usuwanie wg manifestu ──────────────────────────────────────────

async function cleanupRemoved(oldManifest, currentSpecKeys, newManifest) {
  const removed = Object.keys(oldManifest).filter((k) => !currentSpecKeys.includes(k));
  if (removed.length === 0) return;

  // Zbierz eventy i serwisy które są nadal używane przez pozostałe specs
  const stillUsedEvents = new Set(
    Object.values(newManifest).flatMap((e) => e.events || [])
  );
  const stillUsedServices = new Set(
    Object.values(newManifest).flatMap((e) => e.services || [])
  );

  for (const specKey of removed) {
    const entry = oldManifest[specKey];
    console.log(`\n✗ Usunięto spec: ${specKey}`);

    for (const eventId of entry.events || []) {
      if (stillUsedEvents.has(eventId)) {
        console.log(`  ~ event   pominieto (używany przez inny spec): ${eventId}`);
        continue;
      }
      await rmEventById(eventId, '1.0.0').catch(() => {});
      const eventDir = path.join(CATALOG_DIR, 'events', eventId);
      if (fs.existsSync(eventDir)) fs.rmSync(eventDir, { recursive: true, force: true });
      console.log(`  ✗ event   usunieto: ${eventId}`);
    }

    for (const serviceId of entry.services || []) {
      if (stillUsedServices.has(serviceId)) {
        console.log(`  ~ service pominieto (używany przez inny spec): ${serviceId}`);
        continue;
      }
      await rmServiceById(serviceId, '1.0.0').catch(() => {});
      const serviceDir = path.join(CATALOG_DIR, 'services', serviceId);
      if (fs.existsSync(serviceDir)) fs.rmSync(serviceDir, { recursive: true, force: true });
      console.log(`  ✗ service usunieto: ${serviceId}`);
    }
  }
}

// ─── Przetwarzanie pojedynczego pliku spec ────────────────────────────────────

async function processSpec(specPath) {
  const raw = fs.readFileSync(specPath, 'utf8');
  const spec = yaml.load(raw);

  const serviceId = spec.info['x-eventcatalog-id'] || path.basename(specPath, '.yml');
  const ops = normalizeOperations(spec);
  const { sends, receives } = buildSendsReceives(ops);
  const summary = (spec.info.description || '').trim() || spec.info.title;
  const specFilename = path.basename(specPath);

  console.log(`\n→ ${spec.info.title} (${serviceId}) [AsyncAPI ${spec.asyncapi}]`);
  console.log(`  sends:    ${sends.map((s) => s.id).join(', ') || '—'}`);
  console.log(`  receives: ${receives.map((r) => r.id).join(', ') || '—'}`);

  const channelsList = ops
    .map(({ channelName, action, channelDef }) => {
      const arrow = action === 'send' ? '**send** →' : '**receive** ←';
      return `- ${arrow} \`${channelName}\`: ${channelDef.description || ''}`;
    })
    .join('\n');

  await writeService(
    {
      id: serviceId,
      name: spec.info.title,
      version: spec.info.version,
      summary,
      sends,
      receives,
      specifications: { asyncapiPath: specFilename },
      markdown: `## Przegląd\n\n${summary}\n\n## Kanały\n\n${channelsList}\n`,
    },
    { override: true }
  );

  const destDir = path.join(CATALOG_DIR, 'services', serviceId);
  fs.mkdirSync(destDir, { recursive: true });
  fs.copyFileSync(specPath, path.join(destDir, specFilename));
  console.log(`  ✓ service → services/${serviceId}/`);

  const generatedEventIds = await generateEvents(ops, spec);

  return { serviceId, eventIds: generatedEventIds };
}

// ─── Main ─────────────────────────────────────────────────────────────────────

async function main() {
  console.log('EventCatalog AsyncAPI Generator (free / SDK-based)\n');

  const oldManifest = loadManifest();
  const newManifest = {};

  const specFiles = fs
    .readdirSync(SPECS_DIR)
    .filter((f) => f.endsWith('.yml') || f.endsWith('.yaml'))
    .map((f) => path.join(SPECS_DIR, f));

  if (specFiles.length === 0) {
    console.error(`Brak plików YML w ${SPECS_DIR}`);
    process.exit(1);
  }

  // Generuj z aktualnych specs
  for (const specFile of specFiles) {
    const specKey = path.relative(CATALOG_DIR, specFile).replace(/\\/g, '/');
    const { serviceId, eventIds } = await processSpec(specFile);
    newManifest[specKey] = { services: [serviceId], events: eventIds };
  }

  // Usuń wpisy których spec już nie ma
  await cleanupRemoved(oldManifest, Object.keys(newManifest), newManifest);

  saveManifest(newManifest);
  console.log('\nGotowe ✓  (manifest zapisany w .asyncapi-manifest.json)');
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
