import path from 'path';
import url from 'url';

const __dirname = path.dirname(url.fileURLToPath(import.meta.url));

/** @type {import('@eventcatalog/core/bin/eventcatalog.config').Config} */
export default {
  cId: 'ecommerce-catalog',
  title: 'E-Commerce Event Catalog',
  tagline: 'Discover, Explore and Document your Event-Driven Architecture',
  organizationName: 'MyCompany',
  homepageLink: 'https://eventcatalog.dev/',
  trailingSlash: false,
  port: 3000,

  // ─── AsyncAPI Generator ──────────────────────────────────────────────────────
  // Uruchom: npm run generate:asyncapi
  // Generator czyta pliki YML z asyncapi-specs/ i generuje/aktualizuje MDX
  // z właściwymi sends/receives — bez ręcznego pisania frontmatter.
  generators: [
    [
      '@eventcatalog/generator-asyncapi',
      {
        services: [
          {
            path: path.join(__dirname, 'asyncapi-specs', 'order-service.yml'),
            id: 'OrderService',
          },
          {
            path: path.join(__dirname, 'asyncapi-specs', 'payment-service.yml'),
            id: 'PaymentService',
          },
          {
            path: path.join(__dirname, 'asyncapi-specs', 'inventory-service.yml'),
            id: 'InventoryService',
          },
        ],
        domain: { id: 'ECommerce', name: 'E-Commerce', version: '1.0.0' },
      },
    ],
  ],

  // ─── Schema Registry ────────────────────────────────────────────────────────
  // Generator czyta tę konfigurację: npm run generate
  schemaRegistry: {
    url: 'http://localhost:8080/apis/ccompat/v7',

    // Mapowanie prefixu topicu → kto produkuje / kto konsumuje
    services: [
      {
        prefix: 'order.',
        produces: [{ id: 'OrderService',      version: '1.0.0' }],
        consumes: [
          { id: 'InventoryService',    version: '1.0.0' },
          { id: 'PaymentService',      version: '1.0.0' },
          { id: 'NotificationService', version: '1.0.0' },
        ],
      },
      {
        prefix: 'inventory.',
        produces: [{ id: 'InventoryService',   version: '1.0.0' }],
        consumes: [{ id: 'NotificationService', version: '1.0.0' }],
      },
      {
        prefix: 'payment.',
        produces: [{ id: 'PaymentService',     version: '1.0.0' }],
        consumes: [{ id: 'NotificationService', version: '1.0.0' }],
      },
      {
        prefix: 'shipment.',
        produces: [{ id: 'LogisticsService',   version: '1.0.0' }],
        consumes: [{ id: 'NotificationService', version: '1.0.0' }],
      },
      {
        prefix: 'returns.',
          produces: [{ id: 'ReturnsService', version: '1.0.0' }]
      },

    ],
  },
};
