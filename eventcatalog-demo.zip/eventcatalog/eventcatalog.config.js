import path from 'path';
import url from 'url';

const __dirname = path.dirname(url.fileURLToPath(import.meta.url));

/** @type {import('@eventcatalog/core/bin/eventcatalog.config').Config} */
export default {
  cId: 'ecommerce-catalog',
  title: 'E-Commerce Event Catalog',
  tagline: 'Discover, Explore and Document your Event-Driven Architecture',
  organizationName: 'MyCompany',
  homepageLink: 'https://eventcatalog.dev/',
  trailingSlash: false,
  port: 3000,
};
