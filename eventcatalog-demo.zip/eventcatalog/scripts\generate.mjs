/**
 * Generator: AsyncAPI 3.x specs → EventCatalog
 *
 * Czyta pliki YAML z asyncapi-specs/, dla każdego serwisu:
 *  - tworzy/aktualizuje services/{id}/index.mdx (sends + receives)
 *  - tworzy/aktualizuje events/{name}/index.mdx  (dla wiadomości które serwis wysyła)
 *  - kopiuje schemat Avro z schemas/ do events/{name}/schema.avsc
 *
 * Uruchom: npm run generate
 */

import sdk from '@eventcatalog/sdk';
import { parse } from 'yaml';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CATALOG_DIR = path.join(__dirname, '..');
const SPECS_DIR   = path.join(CATALOG_DIR, 'asyncapi-specs');

const { writeEvent, writeService, getEvent, getService } = sdk(CATALOG_DIR);

// ─── Helpers ──────────────────────────────────────────────────────────────────

function readSpec(filePath) {
  return parse(fs.readFileSync(filePath, 'utf8'));
}

/** Rozwiązuje wewnętrzny $ref (#/components/messages/Foo) w obrębie spec */
function resolveLocalRef(ref, spec) {
  const parts = ref.replace(/^#\//, '').split('/');
  return parts.reduce((obj, key) => obj?.[key], spec);
}

/** Zwraca treść schematu Avro (z zewnętrznego pliku $ref) lub null */
function resolveSchemaRef(ref, specDir) {
  if (!ref || ref.startsWith('#/')) return null;
  const absPath = path.resolve(specDir, ref);
  if (!fs.existsSync(absPath)) {
    console.warn(`  ⚠️  Brak pliku schematu: ${absPath}`);
    return null;
  }
  return { content: fs.readFileSync(absPath, 'utf8'), fileName: path.basename(absPath) };
}

/** Generuje sekcję Markdown z nagłówkami wiadomości (CloudEvents / custom) */
function buildHeadersMarkdown(headers) {
  if (!headers?.properties) return '';
  const required = new Set(headers.required ?? []);
  const rows = Object.entries(headers.properties).map(([name, schema]) => {
    const req  = required.has(name) ? '✅' : '—';
    const type = schema.format ? `${schema.type} (${schema.format})` : (schema.type ?? '');
    const val  = schema.const != null ? `\`${schema.const}\`` : '';
    return `| \`${name}\` | ${type} | ${req} | ${val} |`;
  });
  return [
    '## Nagłówki',
    '',
    '| Nagłówek | Typ | Wymagany | Stała wartość |',
    '|----------|-----|:--------:|---------------|',
    ...rows,
  ].join('\n');
}

/** Pobiera rozwiązaną wiadomość + informację o schemacie */
function resolveMessage(msgRef, spec, specDir) {
  const ref = msgRef?.$ref;
  if (!ref) return null;
  const msg = resolveLocalRef(ref, spec);
  if (!msg) return null;

  // Obsługuje dwa warianty AsyncAPI 3.x:
  // 1. msg.schemaFormat + msg.payload.$ref         (klasyczny)
  // 2. msg.payload.schemaFormat + msg.payload.schema.$ref  (alternatywny)
  let schemaRef = null;
  if (msg.schemaFormat?.includes('avro')) {
    schemaRef = msg.payload?.$ref;
  } else if (msg.payload?.schemaFormat?.includes('avro')) {
    schemaRef = msg.payload?.schema?.$ref;
  }
  const schema = schemaRef ? resolveSchemaRef(schemaRef, specDir) : null;

  return { msg, schema };
}

// ─── Główna logika ────────────────────────────────────────────────────────────

async function processSpec(specFile) {
  const specPath = path.join(SPECS_DIR, specFile);
  const specDir  = path.dirname(specPath);
  const spec     = readSpec(specPath);

  if (!spec.asyncapi?.startsWith('3.')) {
    console.warn(`⚠️  Pomijam ${specFile} — wymagane AsyncAPI 3.x`);
    return;
  }

  const serviceId      = spec.info?.['x-eventcatalog-id']
    ?? path.basename(specFile).replace(/\.(ya?ml)$/, '');
  const serviceVersion = spec.info?.version ?? '1.0.0';
  const sends          = [];
  const receives       = [];

  // Dla każdej operacji sprawdź czy serwis send/receive
  for (const op of Object.values(spec.operations ?? {})) {
    // Jeśli operacja nie ma listy messages, pobierz z referencji kanału
    let msgRefs = op.messages ?? [];
    if (msgRefs.length === 0 && op.channel?.$ref) {
      const channel = resolveLocalRef(op.channel.$ref, spec);
      if (channel?.messages) msgRefs = Object.values(channel.messages);
    }

    for (const msgRef of msgRefs) {
      const resolved = resolveMessage(msgRef, spec, specDir);
      if (!resolved) continue;

      const { msg, schema } = resolved;
      const eventId      = msg.name;
      const eventVersion = '1.0.0';

      if (op.action === 'send') sends.push({ id: eventId, version: eventVersion });
      else if (op.action === 'receive') receives.push({ id: eventId, version: eventVersion });

      // Utwórz/zaktualizuj event w katalogu (dla obu kierunków)
      let existingSummary = null;
      let userNotes       = '';
      try {
        const existing  = await getEvent(eventId, eventVersion);
        existingSummary = existing?.summary || null;
        const md        = existing?.markdown ?? '';
        const marker    = md.indexOf('<!-- user -->');
        if (marker !== -1) userNotes = md.slice(marker);
      } catch (_) {}

      if (schema) {
        const eventDir = path.join(CATALOG_DIR, 'events', eventId);
        fs.mkdirSync(eventDir, { recursive: true });
        fs.writeFileSync(path.join(eventDir, schema.fileName), schema.content);
      }

      const headersSection = buildHeadersMarkdown(msg.headers);
      const markdown = [headersSection, userNotes].filter(Boolean).join('\n\n');

      await writeEvent({
        id:         eventId,
        name:       msg.title ?? eventId.replace(/([A-Z])/g, ' $1').trim(),
        version:    eventVersion,
        summary:    existingSummary || msg.summary || op.summary || msg.title || '',
        schemaPath: schema?.fileName,
        markdown,
      }, { override: true });

      console.log(`  ✅ event [${op.action}]: ${eventId}${schema ? ' + schema' : ''}`);
    }
  }

  // Zachowaj istniejący markdown serwisu
  let existingServiceMarkdown = null;
  try {
    const svc = await getService(serviceId, serviceVersion);
    existingServiceMarkdown = svc?.markdown || null;
  } catch (_) {}

  // Skopiuj spec YAML + wszystkie lokalne pliki (schemas/) do katalogu serwisu
  // EventCatalog parsuje spec z tego katalogu — $ref muszą być rozwiązywalne względem niego
  const serviceDir = path.join(CATALOG_DIR, 'services', serviceId);
  fs.mkdirSync(serviceDir, { recursive: true });
  fs.copyFileSync(specPath, path.join(serviceDir, specFile));

  // Kopiuj katalogi z lokalnymi $ref (np. schemas/)
  for (const entry of fs.readdirSync(specDir, { withFileTypes: true })) {
    if (!entry.isDirectory()) continue;
    const srcSubDir = path.join(specDir, entry.name);
    const dstSubDir = path.join(serviceDir, entry.name);
    fs.mkdirSync(dstSubDir, { recursive: true });
    for (const f of fs.readdirSync(srcSubDir)) {
      fs.copyFileSync(path.join(srcSubDir, f), path.join(dstSubDir, f));
    }
  }

  await writeService({
    id:       serviceId,
    name:     spec.info?.title ?? serviceId,
    version:  serviceVersion,
    summary:  spec.info?.description?.trim() ?? '',
    sends,
    receives,
    specifications: [{ type: 'asyncapi', path: specFile }],
    markdown: existingServiceMarkdown ?? '',
  }, { override: true });

  console.log(`  sends:    ${sends.map(e => e.id).join(', ')    || '—'}`);
  console.log(`  receives: ${receives.map(e => e.id).join(', ') || '—'}`);
}

// ─── Entry point ──────────────────────────────────────────────────────────────

const specFiles = fs.readdirSync(SPECS_DIR)
  .filter(f => f.endsWith('.yml') || f.endsWith('.yaml'))
  .sort();

console.log(`\n📂 Specs: ${specFiles.join(', ')}\n`);

for (const file of specFiles) {
  console.log(`→ ${file}`);
  await processSpec(file);
  console.log();
}

console.log('✅ Gotowe\n');
