import utils from '@eventcatalog/sdk';
import path from 'path';
import url from 'url';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CATALOG_DIR = path.join(__dirname, '..');

const configUrl = url.pathToFileURL(path.join(CATALOG_DIR, 'eventcatalog.config.js')).href;
const { default: config } = await import(configUrl);
const { url: REGISTRY_URL, services: SERVICE_MAP } = config.schemaRegistry;

const { writeEvent, writeService, getEvent, getService } = utils(CATALOG_DIR);

function topicToEventName(subject) {
  return subject
    .replace(/-value$/, '')
    .split('.')
    .map(part => part.split('-').map(w => w[0].toUpperCase() + w.slice(1)).join(''))
    .join('');
}

function findMapping(subject) {
  const topic = subject.replace(/-value$/, '');
  return SERVICE_MAP.find(m => topic.startsWith(m.prefix)) ?? null;
}

async function fetchJSON(url) {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status} dla ${url}`);
  return res.json();
}

console.log(`\n🔗 Łączę z Schema Registry: ${REGISTRY_URL}`);

const subjects = await fetchJSON(`${REGISTRY_URL}/subjects`);
const valueSubjects = subjects.filter(s => s.endsWith('-value'));
console.log(`📋 Subjects (${valueSubjects.length}): ${valueSubjects.join(', ')}\n`);

for (const subject of valueSubjects) {
  const { schema: schemaStr, version } = await fetchJSON(
    `${REGISTRY_URL}/subjects/${subject}/versions/latest`
  );
  const schema = JSON.parse(schemaStr);
  const eventName = topicToEventName(subject);
  const eventVersion = `${version}.0.0`;
  const mapping = findMapping(subject);

  // Sprawdź czy event już istnieje — zachowaj summary i markdown
  let existingEvent = null;
  try { existingEvent = await getEvent(eventName, eventVersion); } catch (_) {}

  await writeEvent({
    id: eventName,
    name: eventName.replace(/([A-Z])/g, ' $1').trim(),
    version: eventVersion,
    summary: existingEvent?.summary ?? `Event from topic: ${subject.replace(/-value$/, '')}`,
    schemaPath: 'schema.avsc',
    markdown: existingEvent?.markdown ?? '> Uzupełnij opis eventu.\n',
  }, { override: true });

  // Zapisz schema.avsc bezpośrednio przez fs — SDK nie zawsze to robi niezawodnie
  const schemaPath = path.join(CATALOG_DIR, 'events', eventName, 'schema.avsc');
  fs.writeFileSync(schemaPath, JSON.stringify(schema, null, 2));

  console.log(`✅ ${eventName} v${eventVersion} (schema.avsc zapisany)`);

  if (mapping) {
    for (const producer of (mapping.produces ?? [])) {
      let svc = null;
      try { svc = await getService(producer.id, producer.version); } catch (_) {}
      const sends = svc?.sends ?? [];
      if (!sends.find(e => e.id === eventName)) {
        await writeService({
          id: producer.id,
          name: producer.id.replace(/([A-Z])/g, ' $1').trim(),
          version: producer.version,
          summary: svc?.summary ?? `Service ${producer.id}`,
          sends: [...sends, { id: eventName, version: eventVersion }],
          receives: svc?.receives ?? [],
          markdown: svc?.markdown ?? '',
        }, { override: true });
        console.log(`   ↳ ${producer.id} sends`);
      }
    }

    for (const consumer of (mapping.consumes ?? [])) {
      let svc = null;
      try { svc = await getService(consumer.id, consumer.version); } catch (_) {}
      const receives = svc?.receives ?? [];
      if (!receives.find(e => e.id === eventName)) {
        await writeService({
          id: consumer.id,
          name: consumer.id.replace(/([A-Z])/g, ' $1').trim(),
          version: consumer.version,
          summary: svc?.summary ?? `Service ${consumer.id}`,
          sends: svc?.sends ?? [],
          receives: [...receives, { id: eventName, version: eventVersion }],
          markdown: svc?.markdown ?? '',
        }, { override: true });
        console.log(`   ↳ ${consumer.id} receives`);
      }
    }
  }
}

console.log('\n✅ Gotowe\n');
